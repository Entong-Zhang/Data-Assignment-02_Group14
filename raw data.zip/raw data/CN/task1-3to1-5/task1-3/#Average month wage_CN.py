#Average month wage_CN
import pandas as pd

# 读取 Excel（假设工资总额和就业人数在一个表里）
df = pd.read_excel(r"C:\\Users\\bryennt\\Desktop\\就业_工资_CN.xlsx")

# 去除列名里的多余空格（如果存在）
df.columns = df.columns.str.strip()

# 去掉空格、非数字
for col in ['平均工资_元']:
    df[col] = pd.to_numeric(df[col], errors='coerce')  # 非数字转 NaN

# 去掉有缺失值的行
df = df.dropna(subset=['平均工资_元'])
df['年份'] = pd.to_datetime(df['时间'], errors='coerce').dt.year

# 计算平均月薪
df['平均月薪_元'] = df['平均工资_元'] / 12

# 输出
df.rename(columns={'年份': 'year', '平均月薪_元': 'avg_month_wage_yuan'}, inplace=True)
result = df[['year', 'avg_month_wage_yuan']]
print(result)
result.to_excel(r"C:\Users\bryennt\Desktop\avg_monthly_wage_CN.xlsx", index=False)
