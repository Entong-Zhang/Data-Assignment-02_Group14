import pandas as pd
import os


def clean_and_merge_data():
    unemployment_file = '整体失业率.csv'
    try:
        df_unemployment = pd.read_csv(unemployment_file)
    except FileNotFoundError:
        print(f"未找到文件 {unemployment_file}，请检查文件名和路径。")
        return

    # 劳动力参与率数据
    labor_participation_file = '美国劳动力参与率.csv'
    try:
        df_labor_participation = pd.read_csv(labor_participation_file)
    except FileNotFoundError:
        print(f"未找到文件 {labor_participation_file}，请检查文件名和路径。")
        return

    # 行业数据
    industry_file = '1最新行业数据.csv'
    try:
        df_industry = pd.read_csv(industry_file)
    except FileNotFoundError:
        print(f"未找到文件 {industry_file}，请检查文件名和路径。")
        return

    # 周薪数据
    wage_file = '美国实际周薪中位数（年度）_人民币 (3).xlsx'
    try:
        df_wage = pd.read_excel(wage_file)
    except FileNotFoundError:
        print(f"未找到文件 {wage_file}，请检查文件名和路径。")
        return

    # 工作时间数据
    work_hours_file = '美国工人平均工作时间（年度）.xlsx'
    try:
        df_work_hours = pd.read_excel(work_hours_file)
    except FileNotFoundError:
        print(f"未找到文件 {work_hours_file}，请检查文件名和路径。")
        return



    # 数据清理 - 缺失值处理
    df_unemployment = df_unemployment.dropna()
    df_labor_participation = df_labor_participation.dropna()
    df_industry = df_industry.dropna()
    df_wage = df_wage.dropna()
    df_work_hours = df_work_hours.dropna()
    # df_youth_unemployment = df_youth_unemployment.dropna()

    # 数据清理 - 重复值处理
    df_unemployment = df_unemployment.drop_duplicates()
    df_labor_participation = df_labor_participation.drop_duplicates()
    df_industry = df_industry.drop_duplicates()
    df_wage = df_wage.drop_duplicates()
    df_work_hours = df_work_hours.drop_duplicates()
    # df_youth_unemployment = df_youth_unemployment.drop_duplicates()

    # 整理数据 - 重命名列
    df_unemployment = df_unemployment.rename(columns={
        'Year': 'year',
        'Value': 'unemployment rate'
    })
    df_labor_participation = df_labor_participation.rename(columns={
        'Year': 'year',
        'Value': 'total labor participation rate'
    })
    df_industry = df_industry.rename(columns={
        'Year': 'year',
        'Agriculture': 'employment in agriculture (%)',
        'Industry': 'employment in industry (%)',
        'Services': 'employment in services (%)'
    })
    df_wage = df_wage.rename(columns={
        '日期': 'year',
        '美国2000-2023工人实际周薪中位数（年度）(人民币)': 'wage'
    })
    df_work_hours = df_work_hours.rename(columns={
        'date': 'year',
        'work_hours': 'weekly working hrs'
    })


    # 整理数据 - 筛选美国的数据
    df_unemployment = df_unemployment[df_unemployment['Country Name'] == 'United States']
    df_labor_participation = df_labor_participation[df_labor_participation['Country Name'] == 'United States']
    df_industry = df_industry[df_industry['Country Name'] == 'United States']
    # df_youth_unemployment = df_youth_unemployment[df_youth_unemployment['Country Name'] == 'United States']

    # 提取男性和女性劳动力参与率数据
    female_labor = df_labor_participation[df_labor_participation['Disaggregation'] == 'female, National, 15+']
    male_labor = df_labor_participation[df_labor_participation['Disaggregation'] =='male, National, 15+']
    female_labor = female_labor[['year', 'total labor participation rate']].rename(columns={
        'total labor participation rate': 'labor participation rate(female)'
    })
    male_labor = male_labor[['year', 'total labor participation rate']].rename(columns={
        'total labor participation rate': 'labor participation rate(male)'
    })

    # 合并数据
    merged_data = df_unemployment[['year', 'unemployment rate']]


    # 合并劳动力参与率数据
    merged_data = pd.merge(merged_data, female_labor, on='year', how='left')
    merged_data = pd.merge(merged_data, male_labor, on='year', how='left')
    merged_data = pd.merge(merged_data, df_industry[['year', 'employment in agriculture (%)', 'employment in industry (%)',
                                                   'employment in services (%)']], on='year', how='left')
    merged_data = pd.merge(merged_data, df_wage[['year', 'wage']], on='year', how='left')
    merged_data = pd.merge(merged_data, df_work_hours[['year', 'weekly working hrs']], on='year', how='left')

    # 保存整合后的数据
    output_file = '美国全部数据整合.csv'
    merged_data.to_csv(output_file, index=False)
    print(f"数据已整合并保存为 {output_file}")


if __name__ == "__main__":
    clean_and_merge_data()